import Loading from "@/app/Components/LoadingSpin/Loading";

export default function LoadingPage() {
  return <Loading />;
}
