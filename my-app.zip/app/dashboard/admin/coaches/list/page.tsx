"use client";

import UnifiedUserList from "../../_components/UnifiedUserList";


export default function AdminCoachesPage() {
  return <UnifiedUserList role="coach" />

}