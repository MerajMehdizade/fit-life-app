"use client";
import UnifiedUserList from "../../_components/UnifiedUserList";
export default function AdminAdminsPage() {
  return <UnifiedUserList role="admin" />
}