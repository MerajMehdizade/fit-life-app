export default function SettingsPage() {
  return <div>Admin Settings</div>;
}
