"use client";

import CreateUser from "../../_components/CreateUser";


export default function CreateStudentPage() {

  return (
    <>
      <CreateUser role="student" />
    </>
  );
}
